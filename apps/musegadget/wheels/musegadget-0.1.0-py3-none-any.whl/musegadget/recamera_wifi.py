# Copyright (c) Meta Platforms, Inc. and affiliates.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""WiFi scan/provision through the reCamera Pro's local web API.

The stock Linux client offers one synthetic "current connection" entry and
ignores the Wi-Fi fields the Muse app sends.  On a reCamera Pro we can do
better: the device's own HTTP API (reachable on localhost, no JWT on this
path) scans wlan0 and joins a network.  The app wrapper selects this backend
with ``MUSEGADGET_WIFI_BACKEND=recamera``.

The API is documented in ``reCamera WEB API.md`` and is also what the web UI
uses:

  GET  /network/wifi-status             -> {"iPower": 0|1, ...}
  POST /network/wifi-status?power=on    -> {"code": 0, ...}
  GET  /network/wifi-list               -> [{sSsid, iRssi, sFlags, sConnected, ...}]
  POST /network/wifi  {sSsid,sPassword} -> {"code": 0, "status": 0, "message": ""}

The HTTPS certificate is the device's own self-signed one, so localhost calls
do not verify it.  No token is sent: this path is local-only.
"""

from __future__ import annotations

import json
import logging
import os
import ssl
import time
import urllib.request

log = logging.getLogger(__name__)

WIFI_BACKEND_ENV = "MUSEGADGET_WIFI_BACKEND"
API_ENV = "MUSEGADGET_RECAMERA_API"
DEFAULT_API = "https://127.0.0.1/cgi-bin/entry.cgi"

# The scan endpoint returns cached results; a fresh scan can take a few
# seconds, so poll a small bounded number of times.
SCAN_ATTEMPTS = 5
SCAN_SLEEP_S = 2.0


def enabled() -> bool:
    """Whether the reCamera web API is the Wi-Fi backend for this process."""
    value = os.environ.get(WIFI_BACKEND_ENV, "").strip().lower()
    return value in ("recamera", "recamera-web")


def _api_base() -> str:
    return (os.environ.get(API_ENV) or DEFAULT_API).rstrip("/")


def _context() -> ssl.SSLContext:
    # Localhost only; the device's nginx serves its own self-signed pair.
    context = ssl.create_default_context()
    context.check_hostname = False
    context.verify_mode = ssl.CERT_NONE
    return context


def _request(method: str, path: str, body: dict | None = None,
             timeout: float = 20.0):
    url = _api_base() + path
    data = None
    headers: dict[str, str] = {}
    if body is not None:
        data = json.dumps(body, separators=(",", ":")).encode("utf-8")
        headers["Content-Type"] = "application/json"
    request = urllib.request.Request(url, data=data, method=method, headers=headers)
    with urllib.request.urlopen(request, timeout=timeout,
                                context=_context()) as response:
        raw = response.read()
    if not raw:
        return None
    return json.loads(raw.decode("utf-8"))


def _as_bool(value: object) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        return value.strip().lower() == "true"
    return bool(value)


def _secure(flags: object) -> bool:
    text = str(flags or "").upper()
    return any(token in text for token in ("WPA", "WEP", "PSK", "EAP", "SAE"))


def _entry(raw: dict) -> dict | None:
    ssid = raw.get("sSsid")
    if not isinstance(ssid, str) or not ssid:
        return None
    try:
        rssi = int(raw.get("iRssi", -100))
    except (TypeError, ValueError):
        rssi = -100
    return {"ssid": ssid, "rssi": max(-127, min(0, rssi)),
            "secure": _secure(raw.get("sFlags"))}


def _ensure_power() -> None:
    status = _request("GET", "/network/wifi-status", timeout=8)
    if not isinstance(status, dict) or status.get("iPower") != 1:
        _request("POST", "/network/wifi-status?power=on", timeout=15)
        time.sleep(2)


def _wifi_list() -> list[dict]:
    raw = _request("GET", "/network/wifi-list", timeout=25)
    return raw if isinstance(raw, list) else []


def _merge(raw: list[dict]) -> list[dict]:
    """Map the device list to Muse's {ssid,rssi,secure}, one entry per SSID.

    The device reports every BSSID; the Muse app expects SSIDs.  Prefer a
    connected BSSID, then the strongest signal.
    """
    best: dict[str, tuple[bool, int, dict]] = {}
    for item in raw:
        if not isinstance(item, dict):
            continue
        entry = _entry(item)
        if entry is None:
            continue
        connected = _as_bool(item.get("sConnected"))
        rank = (connected, entry["rssi"])
        previous = best.get(entry["ssid"])
        if previous is None or rank > previous[:2]:
            best[entry["ssid"]] = (connected, entry["rssi"], entry)
    entries = [value[2] for value in best.values()]
    entries.sort(key=lambda item: (-item["rssi"], item["ssid"]))
    return entries


def scan_entries() -> list[dict]:
    """WiFi networks for the Muse app's wifi_scan_result, or [] on failure."""
    if not enabled():
        return []
    try:
        _ensure_power()
    except Exception as exc:  # noqa: BLE001 - scan must degrade to the old path
        log.warning("reCamera wifi power check failed: %s", exc)

    raw: list[dict] = []
    for attempt in range(SCAN_ATTEMPTS):
        try:
            raw = _wifi_list()
        except Exception as exc:  # noqa: BLE001
            log.warning("reCamera wifi scan failed: %s", exc)
            raw = []
        if raw:
            break
        if attempt + 1 < SCAN_ATTEMPTS:
            time.sleep(SCAN_SLEEP_S)

    entries = _merge(raw)

    # Keep a way to stay on the current (typically Ethernet) connection, as
    # the stock client always offered.  The phone sends this label back as the
    # SSID, and configure_wifi() treats it as "no change".
    from musegadget import network  # local import: avoids an import cycle

    connected = next(
        (item for item in raw
         if isinstance(item, dict) and _as_bool(item.get("sConnected"))),
        None,
    )
    current = _entry(connected) if connected is not None else None
    if current is None and network.is_online():
        try:
            current = network.current_connection_entry()
        except Exception:  # noqa: BLE001
            current = {"ssid": network.CURRENT_CONNECTION_LABEL,
                       "rssi": -40, "secure": False}
    if current is not None and not any(
            item["ssid"] == current["ssid"] for item in entries):
        entries.insert(0, current)
    return entries


def configure_wifi(ssid: str, password: str) -> tuple[bool, str]:
    """Join ``ssid`` through the device API; returns (ok, reason)."""
    if not enabled():
        return True, ""
    from musegadget import network  # local import: avoids an import cycle

    if not ssid or ssid == network.CURRENT_CONNECTION_LABEL:
        return True, ""
    try:
        _ensure_power()
    except Exception as exc:  # noqa: BLE001 - connect can still be attempted
        log.warning("reCamera wifi power check failed: %s", exc)

    body = {"sSsid": ssid}
    if password:
        body["sPassword"] = password
    try:
        response = _request("POST", "/network/wifi", body=body, timeout=50)
    except Exception as exc:  # noqa: BLE001
        return False, f"{type(exc).__name__}: {exc}"
    if not isinstance(response, dict):
        return False, "invalid response from reCamera WiFi API"
    code = response.get("code")
    status = response.get("status", 0)
    if code == 0 and status in (0, None):
        return True, ""
    message = str(response.get("message") or "").strip()
    detail = f"code {code}, status {status}"
    if message:
        detail += f", {message}"
    return False, detail