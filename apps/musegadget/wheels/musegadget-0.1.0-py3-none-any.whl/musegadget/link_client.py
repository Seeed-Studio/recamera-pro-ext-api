# Copyright (c) Meta Platforms, Inc. and affiliates.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""One control session with a Muse VM.

Opens a WebSocket to ``/v1/noise`` with the per-VM bearer in an Authorization
header, runs the Noise XX handshake, then opens a long-lived ``POST
/link-control`` stream. Both directions of that stream carry JSON messages,
each prefixed with its length as a little-endian u32:

* device → VM: ``link.register`` (capabilities), then ``link.result`` for
  each invoke;
* VM → device: the register reply, ``link.invoke`` requests, and events such
  as ``link.unpaired``.

Messages the device sends to the Muse (:meth:`LinkSession.send_chat`) go as
separate ``POST /chat/stream`` requests on the same session.
"""

from __future__ import annotations

import asyncio
import base64
import enum
import json
import logging
import re
import struct
import time
import uuid
from collections import deque
from dataclasses import dataclass
from contextlib import asynccontextmanager
from typing import AsyncIterator, Callable, Sequence
from urllib.parse import quote

from musegadget import device_guide, tls
from musegadget.muse_api import user_agent
from musegadget.noise import Header, NoiseTransport, NoiseXXInitiator
from musegadget.streaming import MAX_BUFFER_BYTES, MAX_BUFFER_CHUNKS, StreamingRequest

log = logging.getLogger(__name__)

NOISE_PATH = "/v1/noise"
CONTROL_PATH = "/link-control"
CHAT_PATH = "/chat/stream"
APP_ID = "musegadget"
REQUEST_TIMEOUT_S = 60
MAX_RESPONSE_BYTES = 1024 * 1024
HANDSHAKE_TIMEOUT_S = 20
PING_INTERVAL_S = 20
MAX_CONCURRENT_INVOKES = 4
MAX_INBOUND_MESSAGE = 4 * 1024 * 1024
RECEIVE_FRAMES_PER_TURN = 32
RECEIVE_BYTES_PER_TURN = 64 * 1024
# Documented VM limit: 256 KiB per device control message. Include the u32
# length prefix in our budget, conservatively, not just the JSON payload.
MAX_CONTROL_MESSAGE_BYTES = 256 * 1024
REGISTER_ID_BYTES = 36  # str(uuid.uuid4())
MAX_CHAT_EVENT_BYTES = 256 * 1024
MAX_STREAM_BUFFER_BYTES = 1024 * 1024
MAX_TTS_BUFFER_BYTES = 8 * 1024 * 1024
STREAM_CHUNK_BYTES = 16 * 1024
MAX_VOICE_BYTES = 2 * 1024 * 1024
MAX_IMAGE_BYTES = 2 * 1024 * 1024
IMAGE_MIME_TYPES = ("image/jpeg", "image/png", "image/gif", "image/webp")
REQUEST_CHUNK_BYTES = 16 * 1024
MAX_INLINE_REQUEST_BYTES = 64 * 1024
# Matches JavaScript's encodeURIComponent, as the firmware does.
_URI_COMPONENT_SAFE = "-_.!~*'()"
DEFAULT_MODEL_ID = "muse-gadget-linux"
DEFAULT_MODEL_NAME = "Linux gadget"
MAX_MODEL_NAME_BYTES = 128
_MODEL_ID = re.compile(r"[a-z0-9-]{1,64}")
# Printable ASCII without " or \, so link.register never escapes it.
_MODEL_NAME = re.compile(r"[ !#-\[\]-~]{1,%d}" % MAX_MODEL_NAME_BYTES)


def check_model(model_id: str, model_name: str, guide: str | None) -> None:
    """Raise ValueError for a model id, name or guide outside protocols/DEVICE.md's rules."""
    if not isinstance(model_id, str) or not _MODEL_ID.fullmatch(model_id):
        raise ValueError("model_id must be 1 to 64 lowercase letters, digits and hyphens")
    if not isinstance(model_name, str) or not _MODEL_NAME.fullmatch(model_name):
        raise ValueError(f"model_name must be 1 to {MAX_MODEL_NAME_BYTES} printable ASCII characters, "
                         'without " or \\')
    if guide is not None:
        device_guide.check(guide)


class Outcome(enum.Enum):
    CLOSED = "closed"               # connection ended; reconnect normally
    AUTH_REJECTED = "auth_rejected"  # edge refused the VM bearer; re-fetch VMs
    FORBIDDEN = "forbidden"         # authenticated but not allowed right now
    UNPAIRED = "unpaired"           # the Muse removed this device
    STOPPED = "stopped"


@dataclass(frozen=True)
class DeviceDescription:
    node_id: str
    display_name: str
    version: str
    commands: dict
    model_id: str = DEFAULT_MODEL_ID
    model_name: str = DEFAULT_MODEL_NAME
    guide: str | None = None

    def __post_init__(self) -> None:
        check_model(self.model_id, self.model_name, self.guide)

    def register_params(self) -> dict:
        commands = self.commands
        if self.guide is not None:
            commands = {**commands, device_guide.COMMAND: device_guide.SPEC}
        return {
            "node_id": self.node_id,
            "display_name": self.display_name,
            "platform": "linux",
            "version": self.version,
            "device_family": "gadget",
            "model_id": self.model_id,
            "metadata": {"model_name": self.model_name},
            "is_wakeup_supported": False,
            "commands_v2": commands,
        }

    def register_message(self, request_id: str) -> dict:
        return {"type": "req", "id": request_id, "method": "link.register",
                "params": self.register_params()}


def encode_message(obj: dict) -> bytes:
    data = json.dumps(obj, separators=(",", ":")).encode()
    return struct.pack("<I", len(data)) + data


class MessageDecoder:
    """Splits the control stream into length-prefixed JSON messages.

    A message may span body chunks, so bytes are buffered until complete.
    """

    def __init__(self) -> None:
        self._buf = bytearray()

    def feed(self, data: bytes) -> list[dict]:
        self._buf += data
        messages = []
        while len(self._buf) >= 4:
            (length,) = struct.unpack_from("<I", self._buf)
            if length > MAX_INBOUND_MESSAGE:
                raise ValueError(f"inbound message too large: {length}")
            if len(self._buf) < 4 + length:
                break
            raw = bytes(self._buf[4:4 + length])
            del self._buf[:4 + length]
            if not raw:
                continue  # keepalive
            try:
                message = json.loads(raw)
            except (ValueError, RecursionError):  # malformed, overdeep, or non-UTF-8 JSON
                log.warning("dropping malformed control message (%d bytes)", length)
                continue
            if isinstance(message, dict):
                messages.append(message)
        return messages


def validate_app_id(app_id: str) -> str:
    """Voice app identity is fixed for the entire Noise connection."""
    if app_id == "hatch-web":
        return app_id
    if (isinstance(app_id, str) and app_id.isascii() and app_id.isdecimal()
            and len(app_id) <= 19 and 0 < int(app_id) <= (1 << 63) - 1):
        return str(int(app_id))
    raise ValueError("app ID must be a positive int64 or hatch-web")


def noise_url(noise_host: str, vm_id: str, app_id: str | None = None) -> str:
    url = f"wss://{noise_host}{NOISE_PATH}?vm_id={quote(vm_id, safe=_URI_COMPONENT_SAFE)}"
    if app_id is not None:
        url += "&app_id=" + quote(validate_app_id(app_id), safe="")
    return url


@dataclass(frozen=True)
class SideChat:
    session_id: str
    exists: bool    # False: Muse has no chat with this ID yet; the first send_chat to it creates it


def check_image(image_bytes: bytes, mime_type: str) -> None:
    """Raise ``ValueError`` unless ``LinkSession.send_image`` takes this picture."""
    if mime_type not in IMAGE_MIME_TYPES:
        raise ValueError("images must be JPEG, PNG, GIF or WebP")
    if not image_bytes:
        raise ValueError("the image is empty")
    if len(image_bytes) > MAX_IMAGE_BYTES:
        raise ValueError(f"the image is {len(image_bytes):,} bytes; images must be 2 MiB or less")


class LinkSession:
    def __init__(
        self,
        *,
        noise_host: str,
        vm_id: str,
        vm_auth_token: str,
        device: DeviceDescription,
        run_command: Callable[[str, dict, int | None], dict],
        connect=None,
        invoke_slots: asyncio.Semaphore | None = None,
        app_id: str | None = None,
        register_device: bool = True,
    ) -> None:
        self._url = noise_url(noise_host, vm_id, app_id)
        self._register_device = register_device
        self._transport_ready = asyncio.Event()
        self._token = vm_auth_token
        self._device = device
        self._run_command = run_command
        self._connect = connect
        self._send_lock = asyncio.Lock()
        self._invokes = invoke_slots if invoke_slots is not None else asyncio.Semaphore(MAX_CONCURRENT_INVOKES)
        self._tasks: set[asyncio.Task] = set()
        self._stream_id = 0
        self._register_id = ""
        self._requests: dict[int, _Request | StreamingRequest] = {}
        self._streams: dict[int, HttpStream] = {}
        self._running = False
        self.registered = asyncio.Event()
        self.chat_subscribed = asyncio.Event()
        self._registration_changed = asyncio.Event()
        self._registration_error: Exception | None = None
        self._closed = False
        self._used = False
        self.registered_at: float | None = None

    async def run(self, stop: asyncio.Event) -> Outcome:
        if self._used:
            raise ValueError("a LinkSession can only run once")
        self._used = True
        self.registered.clear()
        self.chat_subscribed.clear()
        ws = None
        reader = stopper = None
        try:
            try:
                ws = await self._open()
            except _UpgradeRejected as rejected:
                log.warning("VM refused connection: HTTP %d", rejected.status)
                return Outcome.AUTH_REJECTED if rejected.status == 401 else Outcome.FORBIDDEN
            self._ws = ws
            self._transport = await asyncio.wait_for(self._handshake(ws), HANDSHAKE_TIMEOUT_S)
            self._running = True
            if self._register_device:
                await self._open_control_stream()
            reader = asyncio.ensure_future(self._read_loop())
            self._transport_ready.set()
            stopper = asyncio.ensure_future(stop.wait())
            done, _ = await asyncio.wait({reader, stopper}, return_when=asyncio.FIRST_COMPLETED)
            if stopper in done:
                return Outcome.STOPPED
            return reader.result()
        finally:
            self._running = False
            self._closed = True
            self.registered.clear()
            self.chat_subscribed.clear()
            self._transport_ready.set()
            self._registration_changed.set()
            tasks = [t for t in (reader, stopper, *self._tasks) if t is not None]
            for task in tasks:
                task.cancel()
            for request in self._requests.values():
                request.fail(ConnectionError("session ended"))
            self._requests.clear()
            for stream in self._streams.values():
                stream.fail(ConnectionError("session ended"))
            self._streams.clear()
            # Close before joining writers stalled by network backpressure.
            if ws is not None:
                try:
                    await asyncio.wait_for(ws.close(), 2)
                except Exception:
                    log.warning("could not close Noise connection")
            if tasks:
                await asyncio.gather(*tasks, return_exceptions=True)

    async def wait_transport_ready(self, timeout: float = HANDSHAKE_TIMEOUT_S) -> None:
        """Wait for the authenticated upgrade, Noise handshake and receive loop.

        With register_device=False no control stream or link.register is sent;
        this preserves another connection's registration for the same device.
        """
        await asyncio.wait_for(self._transport_ready.wait(), timeout)
        if self._closed or not hasattr(self, "_transport"):
            raise ConnectionError("Noise transport did not become ready")

    async def wait_registered(self, timeout: float = HANDSHAKE_TIMEOUT_S) -> None:
        """Wait for the registration ACK, not merely an open WebSocket."""
        if not self._register_device:
            raise ValueError("device registration is disabled on this session")
        await asyncio.wait_for(self._registration_changed.wait(), timeout)
        if self._registration_error is not None:
            raise self._registration_error
        if self._closed or self.registered_at is None:
            raise ConnectionError("session ended before registration")

    # -- Connection setup -----------------------------------------------------

    async def _open(self):
        connect = self._connect
        headers = {"Authorization": f"Bearer {self._token}"}
        if connect is not None:
            return await connect(self._url, headers)
        from websockets.asyncio.client import connect
        from websockets.exceptions import InvalidStatus

        try:
            return await connect(
                self._url,
                additional_headers=headers,
                user_agent_header=user_agent(),
                compression=None,
                open_timeout=HANDSHAKE_TIMEOUT_S,
                ping_interval=PING_INTERVAL_S,
                ping_timeout=PING_INTERVAL_S,
                max_size=128 * 1024,
                ssl=tls.client_context(),
            )
        except InvalidStatus as exc:
            status = exc.response.status_code
            if status in (401, 403):
                raise _UpgradeRejected(status) from None
            raise

    async def _handshake(self, ws) -> NoiseTransport:
        initiator = NoiseXXInitiator()
        initiator.initialize()
        await ws.send(initiator.write_message1())
        msg2 = await ws.recv()
        if isinstance(msg2, str):
            raise ConnectionError("Noise handshake got a text frame")
        initiator.read_message2(bytes(msg2))
        # The bearer already authenticated us at the upgrade; message 3
        # carries an empty payload.
        await ws.send(initiator.write_message3())
        send, recv = initiator.split()
        log.info("Noise session established")
        return NoiseTransport(send, recv)

    async def _open_control_stream(self) -> None:
        encrypted = await self._send_encrypted(
            lambda: self._transport.start_stream_request("POST", CONTROL_PATH),
        )
        self._stream_id = encrypted.stream_id
        self._register_id = str(uuid.uuid4())
        message = self._device.register_message(self._register_id)
        if len(encode_message(message)) > MAX_CONTROL_MESSAGE_BYTES:
            raise ValueError("link.register exceeds the VM's control message budget")
        await self.send(message)
        log.info("sent link.register as %s", self._device.node_id)

    # -- Device-originated requests -------------------------------------------

    async def send_chat(
        self, message: str, session_id: str | None = None, *, output_modality: str = "text",
        device: str | None = None,
    ) -> dict:
        """Post a user message to the Muse as coming from this device.

        Sent on this session, so the VM attributes the turn to the device
        registered on it (``device_id``) and routes any follow-up device
        commands back here. ``session_id`` targets a side chat; an id the Muse
        has not seen before starts a new one. Without it the message goes to
        the main chat. Pass ``output_modality="voice"`` to get a reply that
        ``stream_tts`` can speak. For dictation, ``device="mcu-wearable"`` asks
        Muse for short plain sentences without changing the output modality
        or this session's device identity.
        """
        request_body = {
            "message": message,
            "output_modality": output_modality,
            "device_id": self._device.node_id,
        }
        if session_id:
            request_body["session_id"] = session_id
        if device is not None:
            request_body["device"] = device
        return await self._post_chat(request_body)

    async def send_voice(
        self, wav_bytes: bytes, session_id: str | None = None, *, message: str = "",
        output_modality: str | None = None, device: str | None = None,
    ) -> dict:
        """Post a WAV voice note, optionally including instructions in ``message``.

        Muse reads only the items of a request that has any, so the text goes
        first as its own item. Muse chooses its usual reply format unless
        ``output_modality`` is set. Its TTS endpoint requires a voice-modality
        assistant reply. Pass ``device="mcu-wearable"`` to ask for short plain
        sentences, independently of the output modality and device identity.
        """
        if not wav_bytes or len(wav_bytes) > MAX_VOICE_BYTES:
            raise ValueError("voice note must contain at most 2 MiB of WAV audio")
        voice = {
            "type": "file", "mime_type": "audio/wav", "filename": "voice_note.wav",
            "data_base64": base64.b64encode(wav_bytes).decode("ascii"),
        }
        text = [{"type": "text", "text": message}] if message.strip() else []
        request_body = {
            "message": message,
            "device_id": self._device.node_id,
            "items": text + [voice],
        }
        if session_id:
            request_body["session_id"] = session_id
        if output_modality is not None:
            request_body["output_modality"] = output_modality
        if device is not None:
            request_body["device"] = device
        return await self._post_chat(request_body)

    async def send_image(
        self, image_bytes: bytes, mime_type: str, session_id: str | None = None, *,
        message: str = "", filename: str | None = None, output_modality: str = "text",
    ) -> dict:
        """Post a picture for Muse to look at, with ``message`` as its text.

        ``mime_type`` must be one of ``IMAGE_MIME_TYPES`` and the picture at
        most 2 MiB. Muse reads only the items of a request that has any, so
        the text goes first as its own item.
        """
        check_image(image_bytes, mime_type)
        image = {
            "type": "image", "mime_type": mime_type,
            "data_base64": base64.b64encode(image_bytes).decode("ascii"),
        }
        if filename:
            image["filename"] = filename
        text = [{"type": "text", "text": message}] if message.strip() else []
        request_body = {
            "message": message,
            "output_modality": output_modality,
            "device_id": self._device.node_id,
            "items": text + [image],
        }
        if session_id:
            request_body["session_id"] = session_id
        return await self._post_chat(request_body)

    @staticmethod
    def _http_headers(headers: Sequence[Header] = ()) -> list[Header]:
        return [
            *headers,
            Header("x-request-id", str(uuid.uuid4())),
            Header("x-app-id", APP_ID),
        ]

    async def _post_chat(self, request_body: dict) -> dict:
        if not self._running:
            raise ConnectionError("Muse session is not connected")
        return await self._request(
            "POST", CHAT_PATH, json.dumps(request_body).encode(),
            headers=self._http_headers([Header("Content-Type", "application/json")]),
            timeout=REQUEST_TIMEOUT_S, finish_sends=True,
        )

    async def request(self, method: str, path: str, body: bytes = b"", *,
                      headers=None, timeout: float = REQUEST_TIMEOUT_S) -> dict:
        """Buffered request for small JSON replies, including call cleanup."""
        return await self._request(method, path, body, headers=headers, timeout=timeout)

    async def _request(self, method: str, path: str, body: bytes, *,
                       headers, timeout: float, finish_sends: bool = False) -> dict:
        send = self._send_complete if finish_sends else self._send_encrypted
        upload_in_parts = len(body) > MAX_INLINE_REQUEST_BYTES
        request = _Request(asyncio.get_running_loop().create_future())
        stream_id = None

        def encrypt():
            nonlocal stream_id
            if upload_in_parts:
                encrypted = self._transport.start_stream_request(method, path, headers=headers)
            else:
                encrypted = self._transport.encrypt_http_request(method, path, body, headers=headers)
            stream_id = encrypted.stream_id
            self._requests[stream_id] = request
            return encrypted

        completed = False
        try:
            await send(encrypt)
            if upload_in_parts:
                for offset in range(0, len(body), REQUEST_CHUNK_BYTES):
                    part = body[offset:offset + REQUEST_CHUNK_BYTES]
                    await send(lambda: self._transport.encrypt_body_chunk(
                        stream_id, part, end_body=offset + len(part) == len(body),
                    ))
            status, response = await asyncio.wait_for(request.done, timeout)
            completed = True
        finally:
            if stream_id is not None:
                self._requests.pop(stream_id, None)
            if not request.done.done():
                request.done.cancel()
            elif not request.done.cancelled():
                request.done.exception()  # retrieve send-time failures too
            if not completed and stream_id is not None and not self._closed:
                try:
                    await asyncio.wait_for(self._send_encrypted(
                        lambda: self._transport.encrypt_reset(stream_id, reason="request ended"),
                    ), 1)
                except Exception:
                    log.warning("could not reset abandoned request")
        try:
            decoded = json.loads(response) if response else None
        except (ValueError, UnicodeError, RecursionError):
            decoded = response.decode("utf-8", errors="replace")[:2000]
        return {"ok": 200 <= status < 300, "status": status, "response": decoded}

    @asynccontextmanager
    async def stream_http(
        self, method: str, path: str, body: bytes = b"", *, headers: Sequence[Header] = (),
        max_buffer_bytes: int = MAX_STREAM_BUFFER_BYTES,
    ) -> AsyncIterator[HttpStream]:
        """Open a bounded HTTP response stream; closing it cancels its request.

        The response status and headers are available on entry. Consumers
        iterate byte chunks without holding up the control stream. Pending
        chunks coalesce into 16 KiB buffers. A consumer that exceeds its byte
        budget fails independently; the default budget is 1 MiB.
        """
        if not self._running:
            raise ConnectionError("Muse session is not connected")
        stream = HttpStream(max_buffer_bytes)
        stream_id = None

        def encrypt():
            nonlocal stream_id
            encrypted = self._transport.encrypt_http_request(
                method, path, body, headers=self._http_headers(headers),
            )
            stream_id = encrypted.stream_id
            self._streams[stream_id] = stream
            return encrypted

        try:
            await self._send_complete(encrypt)
            await asyncio.wait_for(stream.ready, REQUEST_TIMEOUT_S)
            yield stream
        finally:
            if stream_id is not None:
                self._streams.pop(stream_id, None)
                if not stream.ended and not stream.reset_requested:
                    stream.reset_requested = True
                    await self._reset_stream(stream_id)
            stream.close()

    async def open_side_chat(self, session_id: str) -> SideChat:
        """Look up the side chat ``session_id`` without reading its events.

        Raises :class:`HttpStreamError` when Muse answers with anything but
        success or 404.
        """
        path = "/chat/subscribe"
        body = json.dumps({"session_id": session_id}).encode()
        async with self.stream_http("POST", path, body, headers=[
            Header("Content-Type", "application/json"), Header("Accept", "application/x-ndjson"),
        ]) as stream:
            if 200 <= stream.status < 300:
                exists = True
            elif stream.status == 404:
                exists = False
            else:
                raise HttpStreamError(stream.status, path)
        return SideChat(session_id, exists)

    async def subscribe_chat(
        self, session_id: str | None = None, *, opened: asyncio.Event | None = None,
    ) -> AsyncIterator[dict]:
        """Yield Muse chat events from its NDJSON subscription.

        ``opened`` is set once Muse accepts this subscription, so events from
        then on reach it.
        """
        body = json.dumps({"session_id": session_id} if session_id else {}).encode()
        path = "/chat/subscribe"
        async with self.stream_http("POST", path, body, headers=[
            Header("Content-Type", "application/json"), Header("Accept", "application/x-ndjson"),
        ]) as stream:
            if not 200 <= stream.status < 300:
                raise HttpStreamError(stream.status, path)
            self.chat_subscribed.set()
            if opened is not None:
                opened.set()
            try:
                buffered = bytearray()
                async for chunk in stream:
                    for part in chunk.splitlines(keepends=True):
                        buffered += part
                        if len(buffered) > MAX_CHAT_EVENT_BYTES:
                            raise ValueError("Muse chat event exceeds 256 KiB")
                        if not buffered.endswith(b"\n"):
                            continue
                        event = self._chat_event(bytes(buffered))
                        buffered.clear()
                        if event is not None:
                            yield event
                if buffered:
                    event = self._chat_event(bytes(buffered))
                    if event is not None:
                        yield event
            finally:
                self.chat_subscribed.clear()

    @staticmethod
    def _chat_event(raw: bytes) -> dict | None:
        if not raw.strip():
            return None
        try:
            event = json.loads(raw)
        except (ValueError, RecursionError):  # malformed, overdeep, or non-UTF-8 JSON
            log.warning("dropping malformed chat event (%d bytes)", len(raw))
            return None
        return event if isinstance(event, dict) and event.get("type") == "event" else None

    async def stream_tts(self, message_id: str) -> AsyncIterator[bytes]:
        """Yield MP3 for a voice-modality assistant reply, with the legacy fallback."""
        encoded_id = quote(message_id, safe=_URI_COMPONENT_SAFE)
        for prefix in ("/api/voice/tts-stream", "/voice/tts-stream"):
            path = f"{prefix}?message_id={encoded_id}"
            async with self.stream_http("GET", path, headers=[Header("Accept", "audio/mpeg")],
                                        max_buffer_bytes=MAX_TTS_BUFFER_BYTES) as stream:
                if stream.status == 404 and prefix == "/api/voice/tts-stream":
                    continue
                if not 200 <= stream.status < 300:
                    raise HttpStreamError(stream.status, prefix)
                async for chunk in stream:
                    yield chunk
                return

    async def _reset_stream(self, stream_id: int) -> None:
        if not self._running:
            return
        try:
            await self._send_complete(
                lambda: self._transport.encrypt_reset(stream_id, reason="consumer closed"),
            )
        except Exception:
            log.debug("could not cancel closed Muse stream", exc_info=True)

    async def stream_request(self, method: str, path: str, *, headers=None,
                             max_buffer_bytes: int = MAX_BUFFER_BYTES,
                             max_buffer_chunks: int = MAX_BUFFER_CHUNKS) -> StreamingRequest:
        if max_buffer_bytes < 1 or max_buffer_chunks < 1:
            raise ValueError("stream limits must be positive")
        stream = None

        def encrypt():
            nonlocal stream
            encrypted = self._transport.start_stream_request(method, path, headers=headers)
            stream = StreamingRequest(self, encrypted.stream_id,
                                      max_buffer_bytes=max_buffer_bytes,
                                      max_buffer_chunks=max_buffer_chunks)
            self._requests[encrypted.stream_id] = stream
            return encrypted

        try:
            await self._send_encrypted(encrypt)
        except BaseException:
            if stream is not None:
                self._requests.pop(stream.stream_id, None)
            raise
        return stream

    # -- Sending --------------------------------------------------------------

    async def send(self, message: dict) -> None:
        if not self._register_device:
            raise ValueError("no device control stream on this session")
        await self._send_complete(lambda: self._transport.encrypt_body_chunk(
            self._stream_id, encode_message(message),
        ))

    async def _send_complete(self, encrypt):
        # Chat/TTS cancellation finishes the current batch, then resets only its
        # stream. Duplex voice sends instead fail the connection if interrupted.
        sender = asyncio.ensure_future(self._send_encrypted(encrypt))
        self._tasks.add(sender)
        sender.add_done_callback(self._tasks.discard)
        cancelled = False
        while True:
            try:
                await asyncio.shield(sender)
                break
            except asyncio.CancelledError:
                cancelled = True
                if sender.done():
                    break
            except Exception:
                if not cancelled:
                    raise
                break
        if cancelled:
            if not sender.cancelled():
                sender.exception()
            raise asyncio.CancelledError
        return sender.result()

    async def _send_encrypted(self, encrypt, *, check=None):
        # Encryption advances the Noise nonce: acquire the lock BEFORE encrypting
        # so concurrent requests and cancelled sends cannot reorder ciphertext.
        async with self._send_lock:
            if self._closed:
                raise ConnectionError("session closed")
            if check is not None:
                check()  # No nonce consumed: a stale stream need not fail the session.
            try:
                result = encrypt()
                frames = result.frames if hasattr(result, "frames") else result
                for frame in frames:
                    await self._ws.send(frame)
                return result
            except BaseException:
                # Delivery is now ambiguous; never reuse this cipher state.
                self._closed = True
                self._running = False
                for request in self._requests.values():
                    request.fail(ConnectionError("send failed"))
                for stream in self._streams.values():
                    stream.fail(ConnectionError("send failed"))
                try:
                    await asyncio.wait_for(self._ws.close(), 2)
                except Exception:
                    log.warning("could not close failed Noise connection")
                raise

    # -- Receiving ------------------------------------------------------------

    async def _read_loop(self) -> Outcome:
        decoder = MessageDecoder()
        received_frames = received_bytes = 0
        while True:
            if (received_frames >= RECEIVE_FRAMES_PER_TURN
                    or received_bytes >= RECEIVE_BYTES_PER_TURN):
                # A buffered recv() may not yield to response consumers or writers.
                await asyncio.sleep(0)
                received_frames = received_bytes = 0
            try:
                raw = await self._ws.recv()
            except Exception as exc:
                log.info("control connection closed: %s", exc)
                return Outcome.CLOSED
            received_frames += 1
            received_bytes += len(raw)
            if isinstance(raw, str):
                log.warning("ignoring text frame on Noise connection")
                continue
            frame = self._transport.decrypt_frame(bytes(raw))
            if frame is None:
                continue
            if not self._register_device or frame.stream_id != self._stream_id:
                stream = self._streams.get(frame.stream_id)
                if stream is not None:
                    if not stream.on_frame(frame):
                        stream.reset_requested = True
                        task = asyncio.ensure_future(self._reset_stream(frame.stream_id))
                        self._tasks.add(task)
                        task.add_done_callback(self._tasks.discard)
                else:
                    self._requests.get(frame.stream_id, _NO_REQUEST).on_frame(frame)
                continue
            if frame.kind == "reset":
                log.warning("control stream reset: %s", frame.value.reason)
                return Outcome.CLOSED
            if frame.kind == "response":
                if not 200 <= frame.value.status < 300:
                    log.warning("/link-control refused: HTTP %d", frame.value.status)
                    return Outcome.FORBIDDEN if frame.value.status == 403 else Outcome.CLOSED
                data, ended = frame.value.body, frame.value.end_body
            else:
                data, ended = frame.value.data, frame.value.end_body
            for message in decoder.feed(data):
                outcome = self._handle(message)
                if outcome is not None:
                    return outcome
            if ended:
                log.info("control stream ended by VM")
                return Outcome.CLOSED

    def _handle(self, message: dict) -> Outcome | None:
        if message.get("id") == self._register_id and message.get("method") is None:
            if message.get("error") or message.get("ok") is False:
                self._registration_error = ConnectionError("link registration rejected")
                self._registration_changed.set()
                log.error("link.register rejected")
                return Outcome.FORBIDDEN
            else:
                self.registered_at = time.monotonic()
                self.registered.set()
                log.info("registered with the Muse")
            self._registration_changed.set()
            return None
        event = message.get("event")
        if event in ("link.unpaired", "node.unpaired"):
            log.warning("the Muse removed this device")
            return Outcome.UNPAIRED
        if message.get("method") == "link.invoke":
            task = asyncio.ensure_future(self._invoke(message))
            self._tasks.add(task)
            task.add_done_callback(self._tasks.discard)
        return None

    async def _invoke(self, message: dict) -> None:
        invoke_id = message.get("id")
        command = message.get("command") or ""
        params = message.get("params") if isinstance(message.get("params"), dict) else {}
        timeout_ms = message.get("timeout_ms") or None
        if not invoke_id:
            return
        if not isinstance(command, str):
            await self.send({"method": "link.result", "id": invoke_id,
                             "ok": False, "error": "command must be a string"})
            return
        shown = printable(command)
        log.info("invoke %s", shown)
        if command == device_guide.COMMAND and self._device.guide is not None:
            result = {"ok": True, "payload": device_guide.payload(self._device.guide)}
            log.info("%s %s in 0 ms", shown, describe_result(result))
            await self.send({"method": "link.result", "id": invoke_id, **result})
            return
        await self._invokes.acquire()
        started = time.monotonic()
        try:
            worker = asyncio.get_running_loop().run_in_executor(
                None, self._run_command, command, params, timeout_ms,
            )
        except BaseException:
            self._invokes.release()
            raise

        def finished(future: asyncio.Future) -> None:
            self._invokes.release()
            # Observe failures even when the disconnected session no longer waits.
            if not future.cancelled():
                future.exception()

        worker.add_done_callback(finished)
        try:
            # Cancelling this session cannot stop a running command thread. Keep its
            # slot until it really finishes, including across service reconnects.
            result = await asyncio.shield(worker)
            summary = describe_result(result)
            # Validate JSON before leaving the callback boundary. Sending
            # remains outside so a broken transport is never retried as a
            # command error.
            encode_message({"method": "link.result", "id": invoke_id, **result})
        except Exception as exc:
            # Callback failures belong to this invocation. Log only the
            # exception type: its text can contain parameters or credentials.
            # Cancellation and other BaseExceptions still propagate, and
            # transport failures remain outside this boundary.
            result = {"ok": False, "error": "command failed"}
            summary = f"failed ({printable(type(exc).__name__)})"
        log.info("%s %s in %d ms", shown, summary,
                 (time.monotonic() - started) * 1000)
        await self.send({"method": "link.result", "id": invoke_id, **result})


def printable(text: str) -> str:
    """text with control characters replaced, so it can't forge log lines."""
    return "".join(ch if ch.isprintable() else "?" for ch in text)


def describe_result(result: dict) -> str:
    """How an invoke ended, for the log. Never its parameters, output or error,
    which can echo them."""
    if not result.get("ok"):
        return "failed"
    payload = result.get("payload")
    if isinstance(payload, dict) and isinstance(payload.get("exit_code"), int):
        timed_out = ", timed out" if payload.get("timed_out") else ""
        return f"ok, exit {payload['exit_code']}{timed_out}"
    return "ok"


class HttpStreamError(ConnectionError):
    """Muse refused an HTTP request carried by the Noise session."""

    def __init__(self, status: int, path: str) -> None:
        super().__init__(f"Muse request {path} failed: HTTP {status}")
        self.status = status
        self.path = path


class RequestRejected(ConnectionError):
    """Muse refused a ``send_chat``, ``send_voice`` or ``send_image`` request."""

    def __init__(self, status: int | None) -> None:
        super().__init__(f"Muse rejected conversation request: HTTP {status}")
        self.status = status


def acknowledgement(result: dict) -> dict:
    """Muse's acknowledgement in a ``send_chat``, ``send_voice`` or ``send_image`` result.

    Raises :class:`RequestRejected` when Muse refused the request, and
    ``ValueError`` when it accepted it without an acknowledgement.
    """
    if not result.get("ok"):
        raise RequestRejected(result.get("status"))
    response = result.get("response")
    if not isinstance(response, dict):
        raise ValueError("Muse did not acknowledge the request")
    return response


class HttpStream:
    """Response headers and bounded byte chunks dispatched by the reader."""

    def __init__(self, max_buffer_bytes: int = MAX_STREAM_BUFFER_BYTES) -> None:
        self.ready = asyncio.get_running_loop().create_future()
        self.status = 0
        self.headers: list[Header] = []
        self.ended = False
        self.reset_requested = False
        self._finished = False
        self._chunks: deque[bytearray] = deque()
        self._available = asyncio.Event()
        self._error: Exception | None = None
        self._buffered = 0
        self._max_buffer_bytes = max_buffer_bytes

    def on_frame(self, frame) -> bool:
        if self._finished:
            return True
        if frame.kind == "reset":
            self.ended = True
            self.fail(ConnectionError("Muse response stream reset"))
            return True
        if frame.kind == "response":
            self.status = frame.value.status
            self.headers = list(frame.value.headers)
            if not self.ready.done():
                self.ready.set_result(None)
            data, ended = frame.value.body, frame.value.end_body
        else:
            if not self.ready.done():
                self.fail(ConnectionError("Muse response body arrived without headers"))
                return False
            data, ended = frame.value.data, frame.value.end_body
        if data:
            if self._buffered + len(data) > self._max_buffer_bytes:
                self.fail(BufferError("Muse response consumer fell behind"))
                return False
            self._buffered += len(data)
            offset = 0
            if self._chunks and len(self._chunks[-1]) < STREAM_CHUNK_BYTES:
                take = min(len(data), STREAM_CHUNK_BYTES - len(self._chunks[-1]))
                self._chunks[-1].extend(data[:take])
                offset = take
            while offset < len(data):
                self._chunks.append(bytearray(data[offset:offset + STREAM_CHUNK_BYTES]))
                offset += STREAM_CHUNK_BYTES
            self._available.set()
        if ended:
            self.ended = self._finished = True
            self._available.set()
        return True

    def fail(self, error: Exception) -> None:
        if self._finished:
            return
        self._finished = True
        if not self.ready.done():
            self.ready.set_exception(error)
        self._drain()
        self._error = error
        self._available.set()

    def _drain(self) -> None:
        self._chunks.clear()
        self._buffered = 0

    def close(self) -> None:
        if not self.ready.done():
            self.ready.cancel()
        self._finished = True
        self._error = None
        self._drain()
        self._available.set()

    def __aiter__(self) -> HttpStream:
        return self

    async def __anext__(self) -> bytes:
        while True:
            if self._chunks:
                chunk = self._chunks.popleft()
                self._buffered -= len(chunk)
                return bytes(chunk)
            if self._error is not None:
                raise self._error
            if self._finished:
                raise StopAsyncIteration
            self._available.clear()
            await self._available.wait()


class _Request:
    """Collects the response to one request stream."""

    def __init__(self, done: asyncio.Future) -> None:
        self.done = done
        self.status = 0
        self.body = bytearray()

    def fail(self, error: Exception) -> None:
        if not self.done.done():
            self.done.set_exception(error)

    def on_frame(self, frame) -> None:
        if self.done.done():
            return
        if frame.kind == "reset":
            self.done.set_exception(ConnectionError(f"stream reset: {frame.value.reason}"))
            return
        if frame.kind == "response":
            if self.status or not 100 <= frame.value.status <= 599:
                self.fail(ValueError("invalid or duplicate response head"))
                return
            self.status = frame.value.status
            data, ended = frame.value.body, frame.value.end_body
        elif frame.kind == "body_chunk" and self.status:
            data, ended = frame.value.data, frame.value.end_body
        else:
            self.fail(ValueError("response body before head"))
            return
        if len(self.body) + len(data) > MAX_RESPONSE_BYTES:
            self.done.set_exception(ValueError("response too large"))
            return
        self.body += data
        if ended:
            self.done.set_result((self.status, bytes(self.body)))


class _NoRequest:
    def on_frame(self, frame) -> None:
        pass


_NO_REQUEST = _NoRequest()


class _UpgradeRejected(Exception):
    def __init__(self, status: int) -> None:
        super().__init__(status)
        self.status = status
